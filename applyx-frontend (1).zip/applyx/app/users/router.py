"""
ApplyX AI - Users Router
==========================
Auth pages + API hooks for your friend to implement
"""

from fastapi import APIRouter
from fastapi.responses import HTMLResponse
import os

router = APIRouter()
TMPL = os.path.join(os.path.dirname(__file__), "templates")

def read(name):
    with open(os.path.join(TMPL, name), encoding="utf-8") as f:
        return f.read()

# ── PAGE ROUTES ──────────────────────────────────────
@router.get("/login",  response_class=HTMLResponse)
def login():   return read("login.html")

@router.get("/signup", response_class=HTMLResponse)
def signup():  return read("signup.html")

# ── API ROUTES (your friend implements these) ──
# @router.post("/api/auth/login")     → { email, password } → { token, user }
# @router.post("/api/auth/signup")    → { name, email, password } → { token, user }
# @router.post("/api/auth/logout")    → invalidate token
# @router.get("/api/auth/me")         → current user info
# @router.put("/api/user/profile")    → update profile
# @router.put("/api/user/notifications") → update notification prefs
# @router.delete("/api/user")         → delete account
# @router.post("/api/billing/upgrade") → Stripe checkout
