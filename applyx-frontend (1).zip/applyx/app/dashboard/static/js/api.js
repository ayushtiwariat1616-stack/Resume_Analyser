/**
 * ApplyX AI — API Client
 * ========================
 * Your friend (backend dev) only needs to edit ONE thing:
 * Set API_BASE to their server URL, then implement the endpoints.
 *
 * Frontend calls these functions — they call the real API.
 * If the API isn't ready yet, it shows loading skeletons.
 */

// ════════════════════════════════════════════════════════
//  CONFIG — Backend dev changes this line only
// ════════════════════════════════════════════════════════
const API_BASE = "http://localhost:8000"; // ← change to prod URL when ready

// ════════════════════════════════════════════════════════
//  AUTH HELPERS
// ════════════════════════════════════════════════════════
const Auth = {
  getToken: () => localStorage.getItem("applyx_token"),
  setToken: (t) => localStorage.setItem("applyx_token", t),
  clear: () => localStorage.removeItem("applyx_token"),
  isLoggedIn: () => !!localStorage.getItem("applyx_token"),
  headers: () => ({
    "Content-Type": "application/json",
    Authorization: `Bearer ${localStorage.getItem("applyx_token")}`,
  }),
};

// ════════════════════════════════════════════════════════
//  BASE FETCHER — handles errors + auth redirect
// ════════════════════════════════════════════════════════
async function apiFetch(path, options = {}) {
  try {
    const res = await fetch(API_BASE + path, {
      headers: Auth.headers(),
      ...options,
    });
    if (res.status === 401) {
      Auth.clear();
      window.location.href = "/login";
      return null;
    }
    if (!res.ok) throw new Error(`API error ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn(`[ApplyX] API not ready: ${path}`, err.message);
    return null; // returns null → UI shows skeleton/placeholder
  }
}

// ════════════════════════════════════════════════════════
//  API ENDPOINTS
//  Backend dev: implement these routes on your server
// ════════════════════════════════════════════════════════

const API = {

  // ── AUTH ──────────────────────────────────────────────
  // POST /api/auth/login   → { token, user: { id, name, email, role, plan } }
  login: (email, password, remember) =>
    apiFetch("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password, remember }),
    }),

  // POST /api/auth/signup  → { token, user }
  signup: (name, email, password) =>
    apiFetch("/api/auth/signup", {
      method: "POST",
      body: JSON.stringify({ name, email, password }),
    }),

  // POST /api/auth/logout
  logout: () => apiFetch("/api/auth/logout", { method: "POST" }),

  // GET /api/auth/me → { id, name, email, role, plan, avatar_url }
  me: () => apiFetch("/api/auth/me"),

  // ── DASHBOARD ─────────────────────────────────────────
  // GET /api/user/stats
  // Returns: { ats_score, trust_score, match_readiness, total_applications, weekly_change }
  stats: () => apiFetch("/api/user/stats"),

  // GET /api/user/ranking
  // Returns: { percentile, outperforming_pct }
  ranking: () => apiFetch("/api/user/ranking"),

  // ── JOBS ──────────────────────────────────────────────
  // GET /api/jobs/recommended?limit=6
  // Returns: [{ id, title, company, location, salary_min, salary_max, match_pct, type }]
  recommendedJobs: (limit = 6) => apiFetch(`/api/jobs/recommended?limit=${limit}`),

  // ── RESUME ────────────────────────────────────────────
  // GET /api/resume/current
  // Returns: { filename, uploaded_at, ats_score, file_url, checks: [{ label, status }] }
  getResume: () => apiFetch("/api/resume/current"),

  // POST /api/resume/upload  (multipart/form-data, key: "resume")
  // Returns: { ats_score, filename, checks: [...], tips: [...] }
  uploadResume: (formData) =>
    fetch(API_BASE + "/api/resume/upload", {
      method: "POST",
      headers: { Authorization: `Bearer ${Auth.getToken()}` },
      body: formData,
    }).then((r) => r.json()),

  // POST /api/resume/improve → { suggestions: [...] }
  improveResume: () => apiFetch("/api/resume/improve", { method: "POST" }),

  // ── APPLICATIONS ──────────────────────────────────────
  // GET /api/applications/summary
  // Returns: { total, interviews, under_review, offers }
  appSummary: () => apiFetch("/api/applications/summary"),

  // GET /api/applications?page=1&limit=20&search=&status=
  // Returns: { applications: [...], total, page, pages }
  getApplications: (params = {}) => {
    const q = new URLSearchParams({ page: 1, limit: 20, ...params }).toString();
    return apiFetch(`/api/applications?${q}`);
  },

  // POST /api/applications  { company, role, job_url, salary, type, match_pct }
  addApplication: (data) =>
    apiFetch("/api/applications", { method: "POST", body: JSON.stringify(data) }),

  // ── ROADMAP ───────────────────────────────────────────
  // GET /api/roadmap
  // Returns: { overall_progress, phases: [{ id, title, status, duration_months, skills, completed_date, progress_pct }] }
  getRoadmap: () => apiFetch("/api/roadmap"),

  // POST /api/roadmap/phase/:id/complete
  completePhase: (id) => apiFetch(`/api/roadmap/phase/${id}/complete`, { method: "POST" }),

  // ── INTERVIEW ─────────────────────────────────────────
  // POST /api/interview/start  { type, difficulty }
  // Returns: { session_id, first_question }
  startInterview: (type, difficulty) =>
    apiFetch("/api/interview/start", { method: "POST", body: JSON.stringify({ type, difficulty }) }),

  // POST /api/interview/message  { session_id, message }
  // Returns: { feedback, score, next_question, tips }
  sendMessage: (session_id, message) =>
    apiFetch("/api/interview/message", { method: "POST", body: JSON.stringify({ session_id, message }) }),

  // ── USER SETTINGS ─────────────────────────────────────
  // PUT /api/user/profile  { name, email, location, linkedin, github }
  updateProfile: (data) =>
    apiFetch("/api/user/profile", { method: "PUT", body: JSON.stringify(data) }),

  // PUT /api/user/notifications  { job_alerts, app_updates, weekly_report }
  updateNotifications: (data) =>
    apiFetch("/api/user/notifications", { method: "PUT", body: JSON.stringify(data) }),

  // POST /api/billing/upgrade  { plan: "pro" } → { checkout_url }
  upgradePlan: (plan = "pro") =>
    apiFetch("/api/billing/upgrade", { method: "POST", body: JSON.stringify({ plan }) }),

  // DELETE /api/user
  deleteAccount: () => apiFetch("/api/user", { method: "DELETE" }),
};

// ════════════════════════════════════════════════════════
//  UI HELPERS — skeleton loaders while API loads
// ════════════════════════════════════════════════════════
const UI = {
  // Show loading skeleton in an element
  skeleton: (el) => {
    el.innerHTML = `<div class="skeleton" style="height:100%;min-height:24px;border-radius:6px;background:linear-gradient(90deg,rgba(255,255,255,0.04) 25%,rgba(255,255,255,0.08) 50%,rgba(255,255,255,0.04) 75%);background-size:200% 100%;animation:shimmer 1.5s infinite"></div>`;
  },

  // Set text safely
  setText: (id, value, fallback = "—") => {
    const el = document.getElementById(id);
    if (el) el.textContent = value ?? fallback;
  },

  // Set a progress ring (0-100)
  setRing: (svgId, labelId, value) => {
    const circumference = 251; // 2 * PI * 40
    const offset = circumference - (value / 100) * circumference;
    const circle = document.querySelector(`#${svgId} .ring-progress`);
    const label = document.getElementById(labelId);
    if (circle) circle.style.strokeDashoffset = offset;
    if (label) label.textContent = value + "%";
  },

  // Show error state
  error: (el, msg = "Failed to load") => {
    el.innerHTML = `<span style="color:var(--muted);font-size:.85rem">${msg}</span>`;
  },
};

// Add shimmer CSS
const style = document.createElement("style");
style.textContent = `@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}`;
document.head.appendChild(style);

// Export for use in page scripts
window.API = API;
window.Auth = Auth;
window.UI = UI;
