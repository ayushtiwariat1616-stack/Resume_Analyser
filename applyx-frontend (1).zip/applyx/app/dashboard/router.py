"""
ApplyX AI - Dashboard Router
==============================
PAGE routes: done ✅  |  API routes: your friend fills these in
"""

from fastapi import APIRouter
from fastapi.responses import HTMLResponse
import os

router = APIRouter()
TMPL = os.path.join(os.path.dirname(__file__), "templates")

def read(name):
    with open(os.path.join(TMPL, name), encoding="utf-8") as f:
        return f.read()

# ── PAGE ROUTES ──────────────────────────────────────
@router.get("/",          response_class=HTMLResponse)
def landing():      return read("index.html")

@router.get("/dashboard", response_class=HTMLResponse)
def dashboard():    return read("dashboard.html")

@router.get("/resume",    response_class=HTMLResponse)
def resume():       return read("resume.html")

@router.get("/applications", response_class=HTMLResponse)
def applications(): return read("applications.html")

@router.get("/roadmap",   response_class=HTMLResponse)
def roadmap():      return read("roadmap.html")

@router.get("/interview", response_class=HTMLResponse)
def interview():    return read("interview.html")

@router.get("/settings",  response_class=HTMLResponse)
def settings():     return read("settings.html")

# ── API ROUTES (your friend adds backend logic here) ──
# @router.get("/api/user/stats")           → ATS, trust, match, applications
# @router.get("/api/jobs/recommended")     → personalized job list
# @router.post("/api/resume/upload")       → PDF upload + ATS analysis
# @router.get("/api/applications/summary") → counts
# @router.get("/api/applications")         → paginated list
# @router.post("/api/applications")        → add new
# @router.get("/api/roadmap")              → phases + progress
# @router.post("/api/interview/start")     → new session
# @router.post("/api/interview/message")   → answer + feedback
