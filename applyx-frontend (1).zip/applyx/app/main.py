"""
ApplyX AI - Main Application Entry Point
=========================================
Frontend-only server. Your friend plugs backend routes into
the dashboard/ and users/ router files.

Run: uvicorn app.main:app --reload
"""

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
import os

app = FastAPI(title="ApplyX AI", version="1.0.0")

# ── Static files ──
BASE = os.path.dirname(__file__)
app.mount("/static", StaticFiles(directory=os.path.join(BASE, "dashboard/static")), name="static")

# ── Import routers (your friend adds backend logic here) ──
from app.dashboard.router import router as dashboard_router
from app.users.router import router as users_router

app.include_router(users_router)
app.include_router(dashboard_router)

@app.get("/health")
def health():
    return {"status": "ok", "app": "ApplyX AI"}
