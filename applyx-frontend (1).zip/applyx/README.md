# ApplyX AI — Frontend

## Structure
```
app/
├── main.py                 ← FastAPI app, mounts routers
├── dashboard/
│   ├── router.py           ← Page routes + API hook comments
│   ├── utils.py            ← Your friend adds helpers here
│   ├── templates/
│   │   ├── index.html      ← Landing page
│   │   ├── dashboard.html  ← Main dashboard
│   │   ├── resume.html     ← Resume analysis
│   │   ├── applications.html
│   │   ├── roadmap.html
│   │   ├── interview.html  ← AI interview bot
│   │   └── settings.html
│   └── static/css/
│       └── dashboard.css   ← Shared styles
└── users/
    ├── router.py           ← Auth routes + API hooks
    ├── utils.py            ← Auth helpers
    └── templates/
        ├── login.html
        └── signup.html
```

## Run
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Then open http://localhost:8000

## For the Backend Developer
Every page has `// BACKEND:` comments showing exactly which API endpoint to implement.
Add your routes in `dashboard/router.py` and `users/router.py`.
